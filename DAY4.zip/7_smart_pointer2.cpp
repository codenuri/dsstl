#include <memory>

int main()
{
	int* p1 = new delete;
	delete p1;

	std::shared_ptr<int> p2(new int);
}