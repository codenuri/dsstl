struct Compare
{
	bool operator()(int a, int b)
	{
		return a < b;
	}
};

template<typename T>
void sort(const T& cmp)
{
	cmp(1, 2);
}

int main()
{
	Compare cmp;
	bool b = cmp(1, 2);
}