class Point
{
	int x, y;
public:
	Point(int x, int y) : x(x), y(y) {}

	bool operator==(const Point& other)
	{
		return x == other.x && y == other.y;
	}
};

int main()
{
	Point p1(1, 1);
	Point p2(2, 2);

	if (p1 == p2)
	{

	}
}




