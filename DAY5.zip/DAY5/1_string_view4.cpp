#include <iostream>
#include <string>
#include <string_view>

void foo(const char* s)		   { std::cout << "const char*\n"; }
void foo(const std::string& s) { std::cout << "std::string\n"; }
void foo(std::string_view   s) { std::cout << "string_view\n"; }

int main()
{
	foo("hello");
}