#include <iostream>
#include <string>
#include <string_view> // C++17 ���� �߰�

int main()
{
	std::string s = "to be or not to be";

	// #1. string vs string_view
	std::string      ss1 = s;
	std::string_view sv1 = s;
	
	

	// #2. literal �ʱ�ȭ
	std::string      ss2 = "practice make best";
	std::string_view sv2 = "practice make best";
}