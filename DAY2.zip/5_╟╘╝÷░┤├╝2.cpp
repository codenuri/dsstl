#include <iostream>
#include <list>
#include <algorithm>

int main()
{
	std::list<int> s = { 1,2,6,4,5,3,7,8,9,10 };

	

	auto ret1 = std::find(s.begin(), s.end(), 3);


	int k = 3;
}




