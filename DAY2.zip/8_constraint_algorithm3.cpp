#include <iostream>
#include <iterator>
#include <list>

template<typename IT, typename T>
IT xfind(IT first, IT last, const T& value)
{
	while (first != last && *first != value)
		++first;

	return first;
}

int main()
{
	std::list<int> s = { 1,2,3,4,5,6,7,8,9,10 };

	std::counted_iterator ci(s.begin(), 5);
}