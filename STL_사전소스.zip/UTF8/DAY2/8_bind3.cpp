﻿#include <iostream>
#include <algorithm>
#include <functional>


int main()
{
    int x[5] = { 9, 9,2,4,3};

    // 3??諛곗닔媛 ?꾨땶 寃껋쓣 李얘퀬 ?띕떎.!

    auto p = std::find_if ( x, x+5, ? ); //
}

















//












//
