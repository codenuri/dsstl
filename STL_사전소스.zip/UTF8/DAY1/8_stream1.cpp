﻿#include <iostream>
#include <iterator>
#include <list>

int main()
{
	int n = 10;

	std::cout << n << std::endl;

	//..


	std::list<int> s = { 1,2,3 };


}
