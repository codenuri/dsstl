﻿// 6_optional
#include <iostream>
#include <optional>

int foo()
{
	// 실패를 알리고 싶다.
	return 100; // 성공
}
int main()
{
	int ret = foo();
}
