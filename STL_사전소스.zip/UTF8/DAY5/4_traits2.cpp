﻿#include <iostream>

template<typename T> void foo(const T& b)
{
	if (? )
		std::cout << "포인터" << std::endl;
	else
		std::cout << "포인터 아님" << std::endl;
	
}

int main()
{
	int n = 10;

	printv(n);
	printv(&n);
}

