﻿#include <iostream>
#include <functional>
using namespace std::placeholders;

void foo(int a, int& b) { b = 100; }

int main()
{	
	std::function<void(int)> f;
	
	int n = 0;

	f = std::bind(&foo, _1, n);  // 이 한줄을 생각 해 봅시다.

	f(0);

	std::cout << n << std::endl; // 결과 예측해 보세요
}


