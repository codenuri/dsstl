﻿// 5_string_view
#include <iostream>
#include <string>
#include <string_view>

void* operator new(std::size_t sz)
{
	std::cout << sz << "메모리 할당" << std::endl;
	return malloc(sz);
}

// 인자로 문자열을 받고 싶습니다.
void foo(std::string name)
{
	// 읽기만 하면 복사본이 필요 없다
}
int main()
{
	std::string s = "sdjfsljflsjlsdkjfssfsd";
	foo(s);
}
