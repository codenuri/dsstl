﻿// 5_string_view
#include <iostream>
#include <string>
#include <string_view> // C++17 에서 추가

int main()
{
	// 아래 2줄의 차이점을 생각해보세요
	char cs1[] = "hello";
	const char* cs2 = "hello";

	std::string s1 = "hello"; // 작은 문자열은 s1(스택에 있는)내부에
							// 긴 문자열은 힙에 할당

	std::string s2 = s1; // 문자열 자체를 복사

	std::string_view sv1 = "hello"; // sv1은 주소와 갯수만 보관
	std::string_view sv2 = s1;      

	std::cout << sizeof(sv1) << std::endl; // 8
}
