﻿#include <iostream>
#include "show.h"

template<typename T> void foo(T a) {}

int main()
{
	// pair : 서로다른 타입 2개를 보관하는 구조체

}


