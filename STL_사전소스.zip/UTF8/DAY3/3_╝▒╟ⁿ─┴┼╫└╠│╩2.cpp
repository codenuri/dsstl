﻿
#include <vector>
#include <iostream>
#include <algorithm>
#include "show.h"

int main()
{
	// 1. 생성
	std::vector<int> v1;
	std::vector<int> v2(10);
	std::vector<int> v3(10, 3);
	std::vector<int> v4(v3);
	std::vector<int> v5{ 10, 3 };
	std::vector<int> v6 = { 1,2,3 };
	

	// 2. 삽입, 


	// 3. 접근
	
	// 4. 요소 변경

}
