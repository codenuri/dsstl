#include <iostream>
#include <list>
#include <vector>
#include <algorithm>
#include <iterator>

int main(int argc, char** argv)
{
	std::vector<int> c1 = { 1,2,3,4,5 };
	std::vector<int> c2 = { 0,0,0,0,0 };

	for (int i = 0; i < 5; i++)
		c2[i] = v1[i];

}
